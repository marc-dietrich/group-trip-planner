"""
API module initialization
"""
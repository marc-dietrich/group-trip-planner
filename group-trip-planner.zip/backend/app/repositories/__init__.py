"""Repository abstractions for persistence layers.

Backwards-compatible shims that forward to app.user_core.repositories.
"""

from app.user_core.repositories import (
    GroupRepository,
    InMemoryGroupRepository,
    SQLModelGroupRepository,
    IdentityRepository,
    InMemoryIdentityRepository,
    SQLModelIdentityRepository,
)

__all__ = [
    "GroupRepository",
    "InMemoryGroupRepository",
    "SQLModelGroupRepository",
    "IdentityRepository",
    "InMemoryIdentityRepository",
    "SQLModelIdentityRepository",
]

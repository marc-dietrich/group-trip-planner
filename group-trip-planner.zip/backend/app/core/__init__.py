"""
Core module initialization
"""
"""
Test package initialization
"""
"""End-to-end happy path using the real database container."""

from datetime import date
import pytest

pytestmark = pytest.mark.asyncio


async def test_group_user_availability_flow(client, user_identity):
    create_group_res = await client.post(
        "/api/groups",
        headers=user_identity["headers"],
        json={"groupName": "System Test Trip", "displayName": "Anon"},
    )
    assert create_group_res.status_code == 200
    group_body = create_group_res.json()
    group_id = group_body["groupId"]

    payload = {
        "startDate": date(2025, 3, 5).isoformat(),
        "endDate": date(2025, 3, 8).isoformat(),
    }
    add_res = await client.post(
        f"/api/groups/{group_id}/availabilities",
        headers=user_identity["headers"],
        json=payload,
    )
    assert add_res.status_code == 200
    availability = add_res.json()
    assert availability["groupId"] == group_id
    assert availability["userId"] == user_identity["user_id"]

    list_res = await client.get(f"/api/groups/{group_id}/availabilities", headers=user_identity["headers"])
    assert list_res.status_code == 200
    items = list_res.json()
    assert len(items) == 1
    assert items[0]["startDate"] == payload["startDate"]
    assert items[0]["endDate"] == payload["endDate"]

    delete_res = await client.delete(
        f"/api/availabilities/{availability['id']}", headers=user_identity["headers"]
    )
    assert delete_res.status_code == 204

    after_delete_res = await client.get(
        f"/api/groups/{group_id}/availabilities", headers=user_identity["headers"]
    )
    assert after_delete_res.status_code == 200
    assert after_delete_res.json() == []

    groups_res = await client.get("/api/groups", headers=user_identity["headers"])
    assert groups_res.status_code == 200
    groups = groups_res.json()
    assert any(g["groupId"] == group_id for g in groups)
